int rol1[] = {2,2,2,3,3};
int rol2[] = {4,3,1,2,2};

void setup(){
Serial.println(random(0, 4))
}